---
title: Halaman Pertama
published: true
---
Perkenalkan, saya Xornandor (nama samaran). Saya saat ini sedang menempuh pendidikan tinggi di Jurusan Teknik Informatika, Program Studi Rekayasa Keamanan Siber. Hobi saya adalah mengeksplor hal-hal yang berkaitan dengan IT, mendengarkan musik, membaca, dan lain-lain.

Blog yang saya buat ini berisi postingan tentang teknologi, pemrograman, keamanan siber, write-up CTF, dan masih banyak lagi. Alasan saya untuk membuat blog ini adalah karena saya suka berbagi ilmu kepada semua orang. Saya harap ilmu yang saya bagikan ini bisa bermanfaat untuk orang lain.

Sekian dari saya, Terimakasih~